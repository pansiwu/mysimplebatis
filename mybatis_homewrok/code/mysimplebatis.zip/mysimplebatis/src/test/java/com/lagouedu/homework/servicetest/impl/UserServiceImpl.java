package com.lagouedu.homework.servicetest.impl;

import com.lagouedu.homework.servicetest.IUserService;

/**
 * @author pansw
 * @date 2020/5/28
 * @apiNote 测试数据层的服务层用户服务实现类
 */
public class UserServiceImpl implements IUserService {
}
