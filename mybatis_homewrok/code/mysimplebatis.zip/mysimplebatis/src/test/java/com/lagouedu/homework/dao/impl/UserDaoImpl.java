package com.lagouedu.homework.dao.impl;

import com.lagouedu.homework.dao.IUserDao;

/**
 * @author pansw
 * @date 2020/5/28
 * @apiNote 操作数据库 用户表 tb_user Dao层实现类
 */
public class UserDaoImpl implements IUserDao {
}
