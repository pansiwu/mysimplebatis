package com.lagouedu.homework.mapper;

import com.lagouedu.homework.pojo.Order;

import java.util.List;

/**
 * Created by xiaow on 2020/5/28
 */
public interface OrderMapper extends BaseMapper {
    public List<Order> findAll();

    public Order findById(Integer orderId);
}
