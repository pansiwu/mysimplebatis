package com.lagouedu.homework.mapper;

/**
 * Created by xiaow on 2020/5/28
 */
public interface UserMapper extends BaseMapper {
}
