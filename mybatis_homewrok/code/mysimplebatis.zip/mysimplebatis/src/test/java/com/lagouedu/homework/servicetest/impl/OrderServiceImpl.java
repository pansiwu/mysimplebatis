package com.lagouedu.homework.servicetest.impl;

import com.lagouedu.homework.dao.IOrderDao;
import com.lagouedu.homework.dao.impl.OrderDaoImpl;
import com.lagouedu.homework.pojo.Order;
import com.lagouedu.homework.servicetest.IOrderService;
import com.lagouedu.homework.sqlsession.SqlSession;
import com.lagouedu.homework.sqlsession.SqlSessionFactory;
import com.lagouedu.homework.sqlsession.SqlSessionFactoryBuilder;
import com.lagouedu.homework.util.Resources;
import org.dom4j.DocumentException;
import org.junit.Test;

import java.beans.IntrospectionException;
import java.beans.PropertyVetoException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;

/**
 * @author pansw
 * @date 2020/5/28
 * @apiNote 测试数据层的服务层订单服务实现类
 */
public class OrderServiceImpl implements IOrderService {
    private IOrderDao orderDao = new OrderDaoImpl();
    @Test
    public void test1() throws PropertyVetoException, DocumentException, IllegalAccessException, IntrospectionException, InstantiationException, NoSuchFieldException, SQLException, InvocationTargetException, ClassNotFoundException {
        InputStream resourceAsSteam = Resources.getResourceAsSteam("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsSteam);
        SqlSession sqlSession = sqlSessionFactory.openSession();

        Order order = sqlSession.selectOne("com.lagouedu.homework.dao.IOrderDao.findAll");
        System.out.println(order);
    }

    @Test
    public void test2() throws PropertyVetoException, DocumentException, IllegalAccessException, IntrospectionException, InstantiationException, NoSuchFieldException, SQLException, InvocationTargetException, ClassNotFoundException {
        InputStream resourceAsSteam = Resources.getResourceAsSteam("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsSteam);
        SqlSession sqlSession = sqlSessionFactory.openSession();

        Order testOrder = new Order();
        testOrder.setOrderId(1);
        Order order = sqlSession.selectOne("com.lagouedu.homework.dao.IOrderDao.findById", testOrder);
        System.out.println(order);
    }

    @Test
    public void test3() throws PropertyVetoException, DocumentException, IllegalAccessException, IntrospectionException, InstantiationException, NoSuchFieldException, SQLException, InvocationTargetException, ClassNotFoundException {
        InputStream resourceAsSteam = Resources.getResourceAsSteam("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsSteam);
        SqlSession sqlSession = sqlSessionFactory.openSession();

        IOrderDao orderDao = sqlSession.getMapper(IOrderDao.class);
        Order order = new Order();
        order.setOrderId(1);

        List<Order> resultOrder = orderDao.findByCondition(order);
        System.out.println(resultOrder);
    }

    @Test
    public void test4() throws PropertyVetoException, DocumentException, IllegalAccessException, IntrospectionException, InstantiationException, NoSuchFieldException, SQLException, InvocationTargetException, ClassNotFoundException {
        InputStream resourceAsSteam = Resources.getResourceAsSteam("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsSteam);
        SqlSession sqlSession = sqlSessionFactory.openSession();

        Order order = new Order();
        order.setOrderId(1);
        order.setOrderName("wangdou");
        order.setOrderDesc("想追的女生");
        int updateRows = sqlSession.update("com.lagouedu.homework.dao.IOrderDao.updateById", order);

        System.out.println(updateRows);
    }

    @Test
    public void test5() throws PropertyVetoException, DocumentException, IllegalAccessException, IntrospectionException, InstantiationException, NoSuchFieldException, SQLException, InvocationTargetException, ClassNotFoundException {
        InputStream resourceAsSteam = Resources.getResourceAsSteam("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsSteam);
        SqlSession sqlSession = sqlSessionFactory.openSession();

        Order order = new Order();
        order.setOrderId(1);
        order.setOrderName("wangdou");
        order.setOrderDesc("想追的女生");
        int updateRows = sqlSession.update("com.lagouedu.homework.dao.IOrderDao.deleteById", order);

        System.out.println(updateRows);
    }

    @Test
    public void test6() throws PropertyVetoException, DocumentException, IllegalAccessException, IntrospectionException, InstantiationException, NoSuchFieldException, SQLException, InvocationTargetException, ClassNotFoundException {
        InputStream resourceAsSteam = Resources.getResourceAsSteam("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsSteam);
        SqlSession sqlSession = sqlSessionFactory.openSession();

        IOrderDao orderDao = sqlSession.getMapper(IOrderDao.class);
        Order order = new Order();
        order.setOrderId(2);

        List<Order> orderList = orderDao.findByCondition(order);
        System.out.println(orderList);
    }

    @Test
    public void test7() throws PropertyVetoException, DocumentException, IllegalAccessException, IntrospectionException, InstantiationException, NoSuchFieldException, SQLException, InvocationTargetException, ClassNotFoundException {
        InputStream resourceAsSteam = Resources.getResourceAsSteam("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsSteam);
        SqlSession sqlSession = sqlSessionFactory.openSession();

        IOrderDao orderDao = sqlSession.getMapper(IOrderDao.class);
        Order order = new Order();
        order.setOrderId(2);
        order.setOrderName("panswAndwangdou");
        order.setOrderDesc("有点希望，加油！！！");
        int rows = orderDao.updateById(order);
        System.out.println(rows);
        List<Order> orderList = orderDao.findAll();
        System.out.println(orderList);
    }

    @Test
    public void test8() throws PropertyVetoException, DocumentException, IllegalAccessException, IntrospectionException, InstantiationException, NoSuchFieldException, SQLException, InvocationTargetException, ClassNotFoundException {
        InputStream resourceAsSteam = Resources.getResourceAsSteam("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsSteam);
        SqlSession sqlSession = sqlSessionFactory.openSession();

        IOrderDao orderDao = sqlSession.getMapper(IOrderDao.class);
        Order order = new Order();
        order.setOrderId(3);
        order.setOrderName("panswAndwangdou");
        order.setOrderDesc("有点希望，加油！！！");
        order.setCreateDate(new Date(System.currentTimeMillis()));
        order.setModifyTime(new Timestamp(System.currentTimeMillis()));
        order.setCreateTime(new Timestamp(System.currentTimeMillis()));
        order.setOrderNote("hello");
        order.setOriginalOrderId(1);
        order.setProductId(1);
        order.setProductNum(3);
        order.setUserId(1);
        int rows = orderDao.addOrder(order);
        System.out.println(rows);
        List<Order> orderList = orderDao.findAll();
        System.out.println(orderList);
    }

    @Test
    public void test9() throws PropertyVetoException, DocumentException, IllegalAccessException, IntrospectionException, InstantiationException, NoSuchFieldException, SQLException, InvocationTargetException, ClassNotFoundException {
        InputStream resourceAsSteam = Resources.getResourceAsSteam("sqlMapConfig.xml");
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsSteam);
        SqlSession sqlSession = sqlSessionFactory.openSession();

        IOrderDao orderDao = sqlSession.getMapper(IOrderDao.class);
        Order order = new Order();
        order.setOrderId(4);
        order.setOrderName("panswAndwangdou");
        order.setOrderDesc("有点希望，加油！！！");
        order.setCreateDate(new Date(System.currentTimeMillis()));
        order.setModifyTime(new Timestamp(System.currentTimeMillis()));
        order.setCreateTime(new Timestamp(System.currentTimeMillis()));
        order.setOrderNote("hello");
        order.setOriginalOrderId(1);
        order.setProductId(1);
        order.setProductNum(5);
        order.setUserId(1);
        int rows = orderDao.addOrder(order);
        System.out.println(rows);
        List<Order> orderList = orderDao.findAll();
        System.out.println(orderList);

        Order delOrder = new Order();
        delOrder.setOrderId(3);
        orderDao.deleteById(delOrder);

        List<Order> orderList1 = orderDao.findAll();
        System.out.println(orderList1);
    }
}
