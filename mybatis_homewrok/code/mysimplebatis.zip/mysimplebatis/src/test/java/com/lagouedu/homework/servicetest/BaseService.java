package com.lagouedu.homework.servicetest;

/**
 * @author pansw
 * @date 2020/5/28
 * @apiNote 测试数据层的服务层总接口
 */
public interface BaseService {
}
