package com.lagouedu.homework.dao.impl;

import com.lagouedu.homework.dao.IOrderDao;
import com.lagouedu.homework.pojo.Order;

import java.util.List;

/**
 * @author pansw
 * @date 2020/5/28
 * @apiNote 操作数据库 订单表 tb_order Dao层实现类
 */
public class OrderDaoImpl implements IOrderDao {
    @Override
    public List<Order> findAll() {
        
        return null;
    }

    @Override
    public Order findById(Integer orderId) {

        return null;
    }

    @Override
    public List<Order> findByCondition(Order order) {
        return null;
    }

    @Override
    public int updateById(Order order) {
        return 0;
    }

    @Override
    public int deleteById(Order order) {
        return 0;
    }

    @Override
    public int addOrder(Order order) {
        return 0;
    }

}
