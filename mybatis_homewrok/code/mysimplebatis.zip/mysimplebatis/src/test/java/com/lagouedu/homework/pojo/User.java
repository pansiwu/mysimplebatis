package com.lagouedu.homework.pojo;

import java.io.Serializable;
import java.lang.annotation.Repeatable;
import java.sql.Timestamp;

/**
 * @author pansw
 * @date  2020/5/28
 * @apiNote 用户实体bean
 */
public class User implements Serializable {
    /**
     * 用户ID
     */
    private Integer userId;
    /**
     * 用户名称
     */
    private String userName;
    /**
     * 用户创建时间
     */
    private Timestamp userCreateTime;

    @Override
    public String toString() {
        return "User{" +
                "userId=" + userId +
                ", userName='" + userName + '\'' +
                ", userCreateTime=" + userCreateTime +
                '}';
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Timestamp getUserCreateTime() {
        return userCreateTime;
    }

    public void setUserCreateTime(Timestamp userCreateTime) {
        this.userCreateTime = userCreateTime;
    }
}
