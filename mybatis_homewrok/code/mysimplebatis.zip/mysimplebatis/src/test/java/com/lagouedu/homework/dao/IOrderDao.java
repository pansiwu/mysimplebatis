package com.lagouedu.homework.dao;

import com.lagouedu.homework.pojo.Order;

import java.util.List;

/**
 * @author pansw
 * @date 2020/5/28
 * @apiNote 操作数据库 订单表 tb_order Dao层接口
 */
public interface IOrderDao {
    List<Order> findAll();

    Order findById(Integer orderId);

    List<Order> findByCondition(Order order);

    int updateById(Order order);

    int deleteById(Order order);

    int addOrder(Order order);

}
