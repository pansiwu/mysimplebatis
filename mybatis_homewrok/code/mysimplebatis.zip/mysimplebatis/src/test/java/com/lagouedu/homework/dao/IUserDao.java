package com.lagouedu.homework.dao;

/**
 * @author pansw
 * @date 2020/5/28
 * @apiNote 操作数据库 用户表 tb_user Dao层接口
 */
public interface IUserDao {
}
