package com.lagouedu.homework.pojo;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

/**
 * @author pansw
 * @date 2020/5/28
 * @apiNote 订单实体bean
 */
public class Order implements Serializable {
    /**
     * 订单id
     */
    private Integer orderId;
    /**
     * 订单名称
     */
    private String orderName;
    /**
     * 下单用户
     */
    private Integer userId;

    private String orderDesc;

    private String orderNote;

    private Integer productId;

    private Integer productNum;

    private Integer originalOrderId;

    private Date createDate;

    private Timestamp createTime;

    private Timestamp modifyTime;

    @Override
    public String toString() {
        return "Order{" +
                "orderId=" + orderId +
                ", orderName='" + orderName + '\'' +
                ", userId=" + userId +
                ", orderDesc='" + orderDesc + '\'' +
                ", orderNote='" + orderNote + '\'' +
                ", productId=" + productId +
                ", productNum=" + productNum +
                ", originalOrderId=" + originalOrderId +
                ", createDate=" + createDate +
                ", createTime=" + createTime +
                ", modifyTime=" + modifyTime +
                '}';
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getOrderName() {
        return orderName;
    }

    public void setOrderName(String orderName) {
        this.orderName = orderName;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getOrderDesc() {
        return orderDesc;
    }

    public void setOrderDesc(String orderDesc) {
        this.orderDesc = orderDesc;
    }

    public String getOrderNote() {
        return orderNote;
    }

    public void setOrderNote(String orderNote) {
        this.orderNote = orderNote;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getProductNum() {
        return productNum;
    }

    public void setProductNum(Integer productNum) {
        this.productNum = productNum;
    }

    public Integer getOriginalOrderId() {
        return originalOrderId;
    }

    public void setOriginalOrderId(Integer originalOrderId) {
        this.originalOrderId = originalOrderId;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public Timestamp getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Timestamp modifyTime) {
        this.modifyTime = modifyTime;
    }
}
