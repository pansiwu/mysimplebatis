package com.lagouedu.homework.pojo;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * @author pansw
 * @date 2020/5/29
 * @apiNote mysimplebaties的sqlmapconfig.xml对应的实体bean
 */
public class Confuguration {
    /**
     *
     */
    private DataSource dataSource;

    /**
     * key:namesapec+"."+id, value:mappedStatement对象
     */
    private Map<String, MappedStatement> mappedStatementMap = new HashMap<>();

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Map<String, MappedStatement> getMappedStatementMap() {
        return mappedStatementMap;
    }

    public void setMappedStatementMap(Map<String, MappedStatement> mappedStatementMap) {
        this.mappedStatementMap = mappedStatementMap;
    }
}
