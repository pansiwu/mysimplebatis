package com.lagouedu.homework.sqlsession;

import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.List;

/**
 * Created by xiaow on 2020/5/30
 */
public interface SqlSession {

    /**
     *
     * @param statementId
     * @param params
     * @param <E>
     * @return
     */
    <E> List<E> selectList(String statementId, Object...params) throws IllegalAccessException, IntrospectionException, InstantiationException, NoSuchFieldException, SQLException, InvocationTargetException, ClassNotFoundException;

    /**
     *
     * @param statementId
     * @param params
     * @param <T>
     * @return
     */
    <T> T selectOne(String statementId, Object...params) throws IllegalAccessException, ClassNotFoundException, IntrospectionException, InstantiationException, SQLException, InvocationTargetException, NoSuchFieldException;

    /**
     *
     * @param mapperClass
     * @param <K>
     * @return
     */
    <K> K getMapper(Class<?> mapperClass);

    /**
     * 新增
     * @param statementId
     * @param params
     * @return
     */
    int insert(String statementId, Object... params) throws ClassNotFoundException, SQLException, IllegalAccessException, NoSuchFieldException;

    /**
     * 删除
     * @param statementId
     * @param params
     * @return
     */
    int delete(String statementId, Object... params) throws ClassNotFoundException, SQLException, IllegalAccessException, NoSuchFieldException;

    /**
     * 修改
     * @param statementId
     * @param params
     * @return
     */
    int update(String statementId, Object... params) throws ClassNotFoundException, SQLException, NoSuchFieldException, IllegalAccessException;
}

