package com.lagouedu.homework.sqlsession;

import com.lagouedu.homework.pojo.Confuguration;

/**
 * Created by xiaow on 2020/5/30
 */
public class DefaultSqlSessionFactory implements SqlSessionFactory {

    private Confuguration confuguration;

    public DefaultSqlSessionFactory(Confuguration confuguration) {
        this.confuguration = confuguration;
    }

    @Override
    public DefaultSqlSession openSession() {
        return new DefaultSqlSession(confuguration, new SimpleExcutor());
    }
}
