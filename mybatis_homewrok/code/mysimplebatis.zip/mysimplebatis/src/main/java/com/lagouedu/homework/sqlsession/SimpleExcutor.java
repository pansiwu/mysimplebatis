package com.lagouedu.homework.sqlsession;

import com.google.common.base.CaseFormat;
import com.google.common.collect.Lists;
import com.lagouedu.homework.pojo.BoundSql;
import com.lagouedu.homework.pojo.Confuguration;
import com.lagouedu.homework.pojo.MappedStatement;
import com.lagouedu.homework.util.GenericTokenParser;
import com.lagouedu.homework.util.ParameterMapping;
import com.lagouedu.homework.util.ParameterMappingTokenHandler;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by xiaow on 2020/5/30
 */
public class SimpleExcutor implements  Excutor {

    /**
     *
     * @param confuguration
     * @param mappedStatement
     * @param params
     * @param <T>
     * @return
     * @throws SQLException
     */
    @Override
    public <T> List<T> query(Confuguration confuguration, MappedStatement mappedStatement, Object... params) throws SQLException, ClassNotFoundException, NoSuchFieldException, IntrospectionException, InvocationTargetException, IllegalAccessException, InstantiationException {
        //创建连接 和 获取sql prepareStatement给占位符？赋值，提取公共方法
        PreparedStatement preparedStatement = getPreparedStatement(confuguration, mappedStatement, params);
        //执行sql
        ResultSet resultSet = preparedStatement.executeQuery();

        //封装返回的结果集
        String resultType = mappedStatement.getResultType();
        Class<?> resultTypeClass = getClassType(resultType);
        ArrayList<Object> objectList = new ArrayList<>();

        while (resultSet.next()) {
            Object o = resultTypeClass.newInstance();

            //元数据对象
            ResultSetMetaData metaData = resultSet.getMetaData();
            for (int i = 1; i <= metaData.getColumnCount(); i++) {
                String columnName = metaData.getColumnName(i);
                Object columValue = resultSet.getObject(columnName);

                //过滤掉JavaBean中没有的属性
                String fieldName = SimpleExcutor.underlineToCamel(columnName);

/*                Field[] resultTypeFields = resultTypeClass.getDeclaredFields();
                boolean b = Arrays.asList(resultTypeFields).contains(fieldName);
                if (b == false) {
                    continue;
                }*/

                //使用反射或者内省，根据数据库表与实体完成映射关系，完成封装
                PropertyDescriptor propertyDescriptor = new PropertyDescriptor(fieldName, resultTypeClass);
                Method writeMethod = propertyDescriptor.getWriteMethod();
                writeMethod.invoke(o, columValue);
            }
            objectList.add(o);
        }
        return (List<T>) objectList;
    }

    /**
     * 创建connection连接和预处理对象prepareStatement、 获取sql prepareStatement给占位符？赋值，提取公共方法
     * @param confuguration
     * @param mappedStatement
     * @param params
     * @return
     * @throws SQLException
     * @throws ClassNotFoundException
     * @throws NoSuchFieldException
     * @throws IllegalAccessException
     */
    private PreparedStatement getPreparedStatement(Confuguration confuguration, MappedStatement mappedStatement, Object... params)
            throws SQLException, ClassNotFoundException, NoSuchFieldException, IllegalAccessException {
        //注册连接 ，获取连接对象connection
        Connection connection = confuguration.getDataSource().getConnection();

        // 获取sqlText语句，并进行转换成jdbc能识别的sql
        String sqlText = mappedStatement.getSqlText();
        BoundSql boundSql = getBoundSql(sqlText);

        // 获取预处理对象：preperdStatement
        PreparedStatement preparedStatement = connection.prepareStatement(boundSql.getSqlText());

        //设置参数
        if(params != null && params.length != 0) {
            String paramterType = mappedStatement.getParamterType();
            Class<?> paramterClassType = getClassType(paramterType);

            List<ParameterMapping> parameterMappingList = boundSql.getParameterMappingList();
            for (int i = 0; i < parameterMappingList.size(); i++) {
                ParameterMapping parameterMapping = parameterMappingList.get(i);
                String content = parameterMapping.getContent();

                //反射
                Field declaredField = paramterClassType.getDeclaredField(content);
                //暴力访问
                declaredField.setAccessible(true);
                Object o = declaredField.get(params[0]);

                preparedStatement.setObject(i + 1, o);

            }

        }
        return preparedStatement;
    }

    @Override
    public int update(Confuguration confuguration, MappedStatement mappedStatement, Object... params) throws SQLException, IllegalAccessException, NoSuchFieldException, ClassNotFoundException {
        //创建connection连接和预处理对象prepareStatement、 获取sql prepareStatement给占位符？赋值，提取公共方法
        PreparedStatement preparedStatement = getPreparedStatement(confuguration, mappedStatement, params);
        //执行sql
        return preparedStatement.executeUpdate();
    }

    private Class<?> getClassType(String className) throws ClassNotFoundException {
        if(className != null) {
            return Class.forName(className);
        }
        return null;
    }

    /**
     * 下划线转驼峰（user_id ==> userId）
     * @param sql
     * @return
     */
    private BoundSql getBoundSql(String sql) {
        ParameterMappingTokenHandler parameterMappingTokenHandler = new ParameterMappingTokenHandler();
        GenericTokenParser genericTokenParser
                = new GenericTokenParser("#{", "}", parameterMappingTokenHandler);
        String parseSql = genericTokenParser.parse(sql);
        List<ParameterMapping> parameterMappingMap = parameterMappingTokenHandler.getParameterMappings();

        return new BoundSql(parseSql, parameterMappingMap);
    }

    public static String underlineToCamel(String colnumName) {
        if (colnumName != null && !"".equals(colnumName)) {
            return CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL, colnumName);
        }
        return "";
    }
}
