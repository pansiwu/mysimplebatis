package com.lagouedu.homework.sqlsession;

import com.lagouedu.homework.pojo.Confuguration;
import org.dom4j.DocumentException;

import java.beans.PropertyVetoException;
import java.io.InputStream;

/**
 * Created by xiaow on 2020/5/30
 */
public class SqlSessionFactoryBuilder {

    public SqlSessionFactory build(InputStream in) throws PropertyVetoException, DocumentException {
        //1.用dom4j解析字节码输入流，封装到JavaBean中
        XMLConfigBuilder xmlConfigBuilder = new XMLConfigBuilder();
        Confuguration confuguration = xmlConfigBuilder.parseConfig(in);
        //2.创建SqlSessionFactory对象
        DefaultSqlSessionFactory defaultSqlSessionFactory = new DefaultSqlSessionFactory(confuguration);
        return defaultSqlSessionFactory;

    }
}
