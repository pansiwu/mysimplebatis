package com.lagouedu.homework.sqlsession;

import com.lagouedu.homework.pojo.Confuguration;
import com.lagouedu.homework.pojo.MappedStatement;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.InputStream;
import java.util.List;

/**
 * Created by xiaow on 2020/5/30
 */
public class XMLMapperBuilder {
    private Confuguration confuguration;

    XMLMapperBuilder(Confuguration confuguration) {
        this.confuguration = confuguration;
    }

    public void paserMapper(InputStream in) throws DocumentException {
        Document document = new SAXReader().read(in);
        Element rootElement = document.getRootElement();
        String namespace = rootElement.attributeValue("namespace");

        setMappedStatement(rootElement, namespace, "select");

        //更新语句用update标签
        setMappedStatement(rootElement, namespace, "update");

        //删除语句 用delete标签
        setMappedStatement(rootElement, namespace, "delete");

        //insert语句，用insert标签
        setMappedStatement(rootElement, namespace, "insert");
    }

    /**
     * 根据传入的insert 、select、update、insert来解析不同类型的sql语句封装到mappedStatement对象中
     * @param rootElement
     * @param namespace
     * @param sqlType
     */
    private void setMappedStatement(Element rootElement, String namespace, String sqlType) {
        List<Element> selectList = rootElement.selectNodes("//" + sqlType);
        for (Element element : selectList) {
            String id = element.attributeValue("id");
            String paramterType = element.attributeValue("paramterType");
            String resultType = element.attributeValue("resultType");
            String sqlText = element.getTextTrim();

            MappedStatement mappedStatement = new MappedStatement();
            mappedStatement.setId(id);
            mappedStatement.setParamterType(paramterType);
            mappedStatement.setResultType(resultType);
            mappedStatement.setSqlText(sqlText);
            mappedStatement.setStatementType(sqlType);

            String key;
            key = namespace + "." + id;
            confuguration.getMappedStatementMap().put(key, mappedStatement);
        }
    }
}
