package com.lagouedu.homework.util;

import java.io.InputStream;

/**
 * Created by xiaow on 2020/5/29
 */
public class Resources {

    public static InputStream getResourceAsSteam(String path) {
        InputStream inputStream = Resources.class.getClassLoader().getResourceAsStream(path);
        return inputStream;
    }
}
