package com.lagouedu.homework.pojo;

/**
 * Created by xiaow on 2020/5/29
 */
public class MappedStatement {

    /**
     *
     */
    private String id;

    /**
     *
     */
    private String statementType;

    /**
     * sql类型 与BoundSql里的sqlType一致，select、 update、 delete、 insert
     */
    private String paramterType;

    /**
     *
     */
    private  String resultType;

    /**
     *
     */
    private String sqlText;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStatementType() {
        return statementType;
    }

    public void setStatementType(String statementType) {
        this.statementType = statementType;
    }

    public String getParamterType() {
        return paramterType;
    }

    public void setParamterType(String paramterType) {
        this.paramterType = paramterType;
    }

    public String getResultType() {
        return resultType;
    }

    public void setResultType(String resultType) {
        this.resultType = resultType;
    }

    public String getSqlText() {
        return sqlText;
    }

    public void setSqlText(String sqlText) {
        this.sqlText = sqlText;
    }
}
