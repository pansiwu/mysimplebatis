package com.lagouedu.homework.sqlsession;

import com.lagouedu.homework.pojo.Confuguration;
import com.lagouedu.homework.pojo.MappedStatement;

import java.beans.IntrospectionException;
import java.lang.module.Configuration;
import java.lang.reflect.*;
import java.sql.SQLException;
import java.util.List;

/**
 * Created by xiaow on 2020/5/30
 */
public class DefaultSqlSession implements SqlSession {

    private  Confuguration confuguration;
    private Excutor excutor;
    public DefaultSqlSession(Confuguration confuguration, Excutor excutor) {
        this.confuguration = confuguration;
        this.excutor = excutor;
    }

    @Override
    public <E> List<E> selectList(String statementId, Object... params) throws IllegalAccessException, IntrospectionException, InstantiationException, NoSuchFieldException, SQLException, InvocationTargetException, ClassNotFoundException {
        MappedStatement mappedStatement = confuguration.getMappedStatementMap().get(statementId);
        return (List<E>) excutor.query(confuguration, mappedStatement, params);
    }

    @Override
    public <T> T selectOne(String statementId, Object... params) throws IllegalAccessException, ClassNotFoundException, IntrospectionException, InstantiationException, SQLException, InvocationTargetException, NoSuchFieldException {
        List<T> list = selectList(statementId, params);
        if (list != null && list.size() == 1) {
            return list.get(0);
        } else {
            throw new RuntimeException("查询结果为空或者查数据存在多条");
        }
    }

    @Override
    public <K> K getMapper(Class<?> mapperClass) {

        Object proxyInstance = Proxy.newProxyInstance(DefaultSqlSession.class.getClassLoader(), new Class[]{mapperClass}, new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                // 1.获取statementId
                String methodName = method.getName();
                String declaringClassName = method.getDeclaringClass().getName();

                String statementId = declaringClassName + "." + methodName;

                MappedStatement mappedStatement = confuguration.getMappedStatementMap().get(statementId);
                switch (mappedStatement.getStatementType()) {
                    case "select":
                        Type genericReturnType = method.getGenericReturnType();

                        if (genericReturnType instanceof ParameterizedType) {
                            return selectList(statementId, args);
                        }

                        return selectOne(statementId, args);

                    case "update":
                        return update(statementId, args);

                    case "insert":
                        return insert(statementId, args);

                    case "delete":
                        return delete(statementId, args);

                    default:
                        break;
                }


                Type genericReturnType = method.getGenericReturnType();

                if (genericReturnType instanceof ParameterizedType) {
                    List<Object> objects = selectList(statementId, args);
                    return objects;
                }

                return selectOne(statementId, args);
            }
        });
        return (K) proxyInstance;
    }

    @Override
    public int insert(String statementId, Object... params) throws ClassNotFoundException, SQLException, IllegalAccessException, NoSuchFieldException {
        return update(statementId, params);
    }

    @Override
    public int delete(String statementId, Object... params) throws ClassNotFoundException, SQLException, IllegalAccessException, NoSuchFieldException {
        return update(statementId, params);
    }

    @Override
    public int update(String statementId, Object... params) throws ClassNotFoundException, SQLException, NoSuchFieldException, IllegalAccessException {
        MappedStatement mappedStatement = confuguration.getMappedStatementMap().get(statementId);
        return excutor.update(confuguration, mappedStatement, params);
    }
}
