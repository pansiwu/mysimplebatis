package com.lagouedu.homework.sqlsession;

import com.lagouedu.homework.pojo.Confuguration;
import com.lagouedu.homework.pojo.MappedStatement;

import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.List;

/**
 * Created by xiaow on 2020/5/30
 */
public interface Excutor {
    /**
     *
     * @param <T>
     * @return
     */
    <T> List<T> query(Confuguration confuguration, MappedStatement mappedStatement, Object... params) throws SQLException, ClassNotFoundException, NoSuchFieldException, IntrospectionException, InvocationTargetException, IllegalAccessException, InstantiationException;

    /**
     *
     * @param confuguration
     * @param mappedStatement
     * @param params
     * @return
     */
    int update(Confuguration confuguration, MappedStatement mappedStatement, Object... params) throws SQLException, IllegalAccessException, NoSuchFieldException, ClassNotFoundException;
}
