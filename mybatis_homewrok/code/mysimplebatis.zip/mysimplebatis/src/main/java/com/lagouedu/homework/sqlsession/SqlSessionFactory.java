package com.lagouedu.homework.sqlsession;

/**
 * Created by xiaow on 2020/5/30
 */
public interface SqlSessionFactory {

    DefaultSqlSession openSession();
}
